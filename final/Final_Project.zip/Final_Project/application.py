from cs50 import SQL
from flask_session import Session
from flask import Flask, render_template, redirect, request, session, jsonify
from datetime import datetime

# # Instantiate Flask object named app
app = Flask(__name__)

# # Configure sessions
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Creates a connection to the database
db = SQL ( "sqlite:///data.db" )

@app.route("/")
def index():
    products = db.execute("SELECT * FROM products ORDER BY onSalePrice")
    productsLen = len(products)
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    if 'user' in session:
        shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
        shopLen = len(shoppingCart)
        for i in range(shopLen):
            total += shoppingCart[i]["SUM(subTotal)"]
            totItems += shoppingCart[i]["SUM(quantity)"]
        products = db.execute("SELECT * FROM products ORDER BY id ASC")
        productsLen = len(products)
        return render_template ("index.html", shoppingCart=shoppingCart, products=products, shopLen=shopLen, productsLen=productsLen, total=total, totItems=totItems, display=display, session=session )
    return render_template ( "index.html", products=products, shoppingCart=shoppingCart, productsLen=productsLen, shopLen=shopLen, total=total, totItems=totItems, display=display)

@app.route("/buy/")
def buy():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    qty = int(request.args.get('quantity'))
    if session:
        id = int(request.args.get('id'))
        goods = db.execute("SELECT * FROM products WHERE id = :id", id=id)
        if(goods[0]["onSale"] == 1):
            price = goods[0]["onSalePrice"]
        else:
            price = goods[0]["price"]
        samplename = goods[0]["samplename"]
        image = goods[0]["image"]
        subTotal = qty * price
        db.execute("INSERT INTO cart (id, quantity, samplename, image, price, subTotal) VALUES (:id, :qty, :samplename, :image, :price, :subTotal)", id=id, qty=qty, samplename=samplename, image=image, price=price, subTotal=subTotal)
        shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
        shopLen = len(shoppingCart)
        for i in range(shopLen):
            total += shoppingCart[i]["SUM(subTotal)"]
            totItems += shoppingCart[i]["SUM(quantity)"]
        products = db.execute("SELECT * FROM products ORDER BY samplename ASC")
        productsLen = len(products)
    return render_template ("index.html", shoppingCart=shoppingCart, products=products, shopLen=shopLen, productsLen=productsLen, total=total, totItems=totItems, display=display, session=session )


@app.route("/update/")
def update():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    quantity = int(request.args.get('quantity'))
    if session:
        id = int(request.args.get('id'))
        db.execute("DELETE FROM cart WHERE id = :id", id=id)
        goods = db.execute("SELECT * FROM products WHERE id = :id", id=id)
        if(goods[0]["onSale"] == 1):
            price = goods[0]["onSalePrice"]
        else:
            price = goods[0]["price"]
        samplename = goods[0]["samplename"]
        image = goods[0]["image"]
        subTotal = quantity * price
        db.execute("INSERT INTO cart (id, quantity, samplename, image, price, subTotal) VALUES (:id, :quantity, :samplename, :image, :price, :subTotal)", id=id, quantity=quantity, samplename=samplename, image=image, price=price, subTotal=subTotal)
        shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
        shopLen = len(shoppingCart)
        for i in range(shopLen):
            total += shoppingCart[i]["SUM(subTotal)"]
            totItems += shoppingCart[i]["SUM(quantity)"]
        return render_template ("cart.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session )


@app.route("/updateinventory/", methods=["POST"])
def updateinventory():
    if request.method == 'POST':
        print("In if condition")
        id = int(request.form["id"])
        name = request.form["samplename"]
        price = float(request.form["price"])
        onSalePrice = float(request.form["onSalePrice"])
        quantity = int(request.form["quantity"])

        print("Received form values:")
        print("id:", id, type(id))
        print("name:", name, type(name))
        print("price:", price, type(price))
        print("onSalePrice:", onSalePrice, type(onSalePrice))
        print("quantity:", quantity, type(quantity))
        db.execute("UPDATE products SET samplename = :name, price = :price, onSalePrice = :onSalePrice, quantity = :quantity WHERE id = :id",
                            {"name": name, "price": price, "onSalePrice": onSalePrice, "quantity": quantity, "id": id})

        return render_template("inventory.html")
    else:
        print("Inside else condition")
        shoppingCart = []
        shopLen = len(shoppingCart)
        totItems, total, display = 0, 0, 0
        id = request.args.get('id')
        if id is not None:
            id = int(id)
            myproducts = db.execute("SELECT * FROM products WHERE id = :query", query=id)
            myproductsLen = len(myproducts)
            print("Product is " + str(myproducts))
            if len(myproducts) > 0:
                product_data = myproducts[0]
                return render_template("inventory.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session, myproducts=myproducts, myproductsLen=myproductsLen, product=product_data)
            else:
                return render_template("product_not_found.html")
        else:
            return render_template("product_id_missing.html")

@app.route("/filter/")
def filter():
    if request.args.get('typeProduct'):
        query = request.args.get('typeProduct')
        products = db.execute("SELECT * FROM products WHERE typeProduct = :query ORDER BY samplename ASC", query=query )
    if request.args.get('sale'):
        query = request.args.get('sale')
        products = db.execute("SELECT * FROM products WHERE onSale = :query ORDER BY samplename ASC", query=query)
    if request.args.get('id'):
        query = int(request.args.get('id'))
        products = db.execute("SELECT * FROM products WHERE id = :query ORDER BY samplename ASC", query=query)
    if request.args.get('price'):
        query = request.args.get('price')
        products = db.execute("SELECT * FROM products ORDER BY onSalePrice ASC")
    productsLen = len(products)
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    if 'user' in session:
        shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
        shopLen = len(shoppingCart)
        for i in range(shopLen):
            total += shoppingCart[i]["SUM(subTotal)"]
            totItems += shoppingCart[i]["SUM(quantity)"]
        return render_template ("index.html", shoppingCart=shoppingCart, products=products, shopLen=shopLen, productsLen=productsLen, total=total, totItems=totItems, display=display, session=session )
    return render_template ( "index.html", products=products, shoppingCart=shoppingCart, productsLen=productsLen, shopLen=shopLen, total=total, totItems=totItems, display=display)

@app.route("/redirectinventory/", methods=["POST"])
def redirectinventory():
    db.execute("DELETE FROM products WHERE id = 1")
    db.execute("INSERT INTO products (id, samplename, image, price, onSale, onSalePrice, typeProduct, quantity) VALUES(:id, :samplename, :image, :price, :onSale, :onSalePrice, :typeProduct, :quantity)", id=1, samplename='Camera1', image='camera1.jpg', price=88.0, onSale=1, onSalePrice=78.0, typeProduct='camera', quantity=120 )
    return redirect("/inventory")


@app.route("/payment/")
def payment():
    order = db.execute("SELECT * from cart")
    date = datetime.now()
    print(date)
    for item in order:
        db.execute("INSERT INTO purchases (uid, id, samplename, image, quantity, date) VALUES(:uid, :id, :samplename, :image, :quantity, :date)", uid=session["uid"], id=item["id"], samplename=item["samplename"], image=item["image"], quantity=item["quantity"], date = date )
        qty0 = int(item["quantity"])
        prod = db.execute("SELECT * from products where id = :id", id=item["id"])
        if len(prod) > 0:
            prod = prod[0]
            qty1 = int(prod["quantity"])
            qty = int(qty1 - qty0)
            db.execute("DELETE FROM products where id = :id", id = item["id"])
            db.execute("INSERT INTO products (id, samplename, image, price, onSale, onSalePrice, typeProduct, quantity) VALUES(:id, :samplename, :image, :price, :onSale, :onSalePrice, :typeProduct, :quantity)", id=item["id"], samplename=item["samplename"], image=item["image"], price=prod["price"], onSale=prod["onSale"], onSalePrice=prod["onSalePrice"], typeProduct=prod["typeProduct"], quantity=qty )
    db.execute("DELETE from cart")
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    products = db.execute("SELECT * FROM products ORDER BY samplename ASC")
    productsLen = len(products)
    return redirect('/thankyou')
    
@app.route("/thankyou/")
def thankyou():
    shoppingCart = []
    shopLen = len(shoppingCart)
    return render_template("thankyou.html")

@app.route("/checkout/")
def checkout():
    shoppingCart = []
    shopLen = len(shoppingCart)
    return render_template('payment.html',shopLen=shopLen,shoppingCart=shoppingCart)

@app.route("/remove/", methods=["GET"])
def remove():
    out = int(request.args.get("id"))
    db.execute("DELETE from cart WHERE id=:id", id=out)
    totItems, total, display = 0, 0, 0
    shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
    shopLen = len(shoppingCart)
    for i in range(shopLen):
        total += shoppingCart[i]["SUM(subTotal)"]
        totItems += shoppingCart[i]["SUM(quantity)"]
    display = 1
    return render_template ("cart.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session )

@app.route("/hi/", methods=["POST"])
def hi():
    shoppingCart = []
    shopLen = len(shoppingCart)
    return render_template("hi.html", shoppingCart=shoppingCart, shopLen=shopLen)

@app.route("/login/", methods=["GET"])
def login():
    admin = False
    return render_template("signin.html", admin = admin)

@app.route("/signin/", methods = ["GET"])
def signin():
    return render_template("login.html")

@app.route("/adminlogin", methods = ["GET"])
def adminlogin():
    return render_template("adminlogin.html")


@app.route("/new/", methods=["GET"])
def new():
    return render_template("new.html")
@app.route("/logged/", methods=["POST"] )
def logged():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0    
    user = request.form["username"].lower()
    pwd = request.form["password"]
    if user == "" or pwd == "":
        return render_template ("login.html")
    query = "SELECT * FROM users WHERE username = :user AND password = :pwd"
    rows = db.execute ( query, user=user, pwd=pwd )
    if len(rows) == 1:
        session['user'] = user
        session['time'] = datetime.now( )
        session['uid'] = rows[0]["id"]
        session['typeUser'] = rows[0]["typeUser"]
    else:
         return render_template ( "login.html", msg="Wrong username or password." )

    myproducts = db.execute("SELECT * FROM purchases WHERE uid=:uid", uid=session['uid'])
    myproductsLen = len(myproducts)
    products = db.execute("SELECT * FROM products ORDER BY samplename ASC")
    productsLen = len(products)
    if 'user' in session:
        username = session.get('user')
        session['admin'] = session['typeUser']
        return render_template ("index.html", shoppingCart=shoppingCart, products=products, shopLen=shopLen, productsLen=productsLen, total=total, totItems=totItems, display=display, session=session)

    return render_template ( "login.html", msg="Wrong username or password." )

@app.route("/adminlogged/", methods=["POST"] )
def adminlogged():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0    
    user = request.form["username"].lower()
    pwd = request.form["password"]
    if user == "" or pwd == "":
        return render_template ( "adminlogin.html" )
    query = "SELECT * FROM users WHERE username = :user AND password = :pwd"
    rows = db.execute ( query, user=user, pwd=pwd )
    if len(rows) == 1 and rows[0]['typeUser'] == 1:
        session['user'] = user
        session['time'] = datetime.now()
        session['uid'] = rows[0]["id"]
        session['typeUser'] = rows[0]["typeUser"]
    elif len(rows) == 1 and rows[0]['typeUser'] == 0:
        return render_template ( "adminlogin.html", msg="You are not registered as an admin." )
    else:
         return render_template ( "adminlogin.html", msg="Wrong username or password." )
    myproducts = db.execute("SELECT * FROM purchases WHERE uid=:uid", uid=session['uid'])
    myproductsLen = len(myproducts)
    products = db.execute("SELECT * FROM products ORDER BY samplename ASC")
    productsLen = len(products)
    if 'user' in session:
        username = session.get('user')
        session['admin'] = session['typeUser']  
        return render_template ("inventory.html", shoppingCart=shoppingCart, products=products, shopLen=shopLen, productsLen=productsLen, total=total, totItems=totItems, display=display, session=session)
    return render_template ( "login.html", msg="Wrong username or password." )



@app.route("/history/")
def history():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    myproducts = db.execute("SELECT * FROM purchases WHERE uid=:uid order by date DESC", uid=session["uid"])
    myproductsLen = len(myproducts)
    return render_template("history.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session, myproducts=myproducts, myproductsLen=myproductsLen)

@app.route("/inventory/", methods=["GET", "POST"])
def inventory():
    shoppingCart = []
    shopLen = len(shoppingCart)
    totItems, total, display = 0, 0, 0
    if 'user' in session and session['typeUser'] == 1:  # Check if the user is an admin
        if request.method == 'POST':
            id = request.form["id"]
            name = request.form["samplename"]
            price = request.form["price"]
            onSalePrice = request.form["onSalePrice"]
            quantity = request.form["quantity"]
            query = db.execute("UPDATE products SET samplename = :name, price = :price, onSalePrice = :onSalePrice, quantity = :quantity WHERE id = :id",
                               {"name": name, "price": price, "onSalePrice": onSalePrice, "quantity": quantity, "id": id})

            return render_template("inventory.html")

        else:
            myproducts = db.execute("SELECT * FROM products")
            myproductsLen = len(myproducts)
            return render_template("inventory.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session, myproducts=myproducts, myproductsLen=myproductsLen)
    else:
        return redirect("/login/")
    
@app.route("/update_product/", methods=["GET", "POST"])
def update_product():
    if request.method == 'POST':
        print("In if condition")
        id = int(request.form["id"])
        name = request.form["samplename"]
        price = float(request.form["price"])
        onSalePrice = float(request.form["onSalePrice"])
        quantity = int(request.form["quantity"])

        print("Received form values:")
        print("id:", id, type(id))
        print("name:", name, type(name))
        print("price:", price, type(price))
        print("onSalePrice:", onSalePrice, type(onSalePrice))
        print("quantity:", quantity, type(quantity))
        db.execute("UPDATE products SET samplename = :name, price = :price, onSalePrice = :onSalePrice, quantity = :quantity WHERE id = :id",
                            {"name": name, "price": price, "onSalePrice": onSalePrice, "quantity": quantity, "id": id})

        return render_template("inventory.html")
    else:
        print("Inside else condition")
        shoppingCart = []
        shopLen = len(shoppingCart)
        totItems, total, display = 0, 0, 0
        id = request.args.get('id')
        if id is not None:
            id = int(id)
            myproducts = db.execute("SELECT * FROM products WHERE id = :query", query=id)
            myproductsLen = len(myproducts)
            print("Product is " + str(myproducts))
            if len(myproducts) > 0:
                product_data = myproducts[0]
                return render_template("update_product.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session, myproducts=myproducts, myproductsLen=myproductsLen, product=product_data)
            else:
                return render_template("product_not_found.html")
        else:
            return render_template("product_id_missing.html")


@app.route("/logout/")
def logout():
    db.execute("DELETE from cart")
    session.clear()
    return redirect("/")

@app.route("/contactus/")
def contactus():
    return render_template("contactus.html")

@app.route("/contactquery/")
def contactquery():
    return render_template("contactquery.html")

@app.route("/register/", methods=["POST"] )
def registration():
    username = request.form["username"]
    password = request.form["password"]
    confirm = request.form["confirm"]
    fname = request.form["fname"]
    lname = request.form["lname"]
    email = request.form["email"]
    rows = db.execute( "SELECT * FROM users WHERE username = :username ", username = username )
    if len( rows ) > 0:
        return render_template ( "new.html", msg="Username already exists!" )
    typeUser = 0
    new = db.execute ( "INSERT INTO users (username, password, fname, lname, email, typeUser) VALUES (:username, :password, :fname, :lname, :email, :typeUser)",
                    username=username, password=password, fname=fname, lname=lname, email=email, typeUser=typeUser )
    return render_template ( "login.html" )


@app.route("/cart/")
def cart():
    if 'user' in session:
        totItems, total, display = 0, 0, 0
        shoppingCart = db.execute("SELECT samplename, image, SUM(quantity), SUM(subTotal), price, id FROM cart GROUP BY samplename")
        shopLen = len(shoppingCart)
        for i in range(shopLen):
            total += shoppingCart[i]["SUM(subTotal)"]
            totItems += shoppingCart[i]["SUM(quantity)"]
    return render_template("cart.html", shoppingCart=shoppingCart, shopLen=shopLen, total=total, totItems=totItems, display=display, session=session)
