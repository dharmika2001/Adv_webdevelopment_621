// The submit button
const SUBMIT = document.getElementById("submit");
// Object destructuring
const {
    username: USERNAME,
    userMsg: USERNAME_MSG,
    password: PASSWORD,
    passwordMsg: PASSWORD_MSG,
    confirm: CONFIRM,
    confirmMsg: CONFIRM_MSG,
    fname: FNAME,
    fnameMsg: FNAME_MSG,
    lname: LNAME,
    lnameMsg: LNAME_MSG,
    email: EMAIL,
    emailMsg: EMAIL_MSG,
  } = {
    username: $("#username"),
    userMsg: $("#user-msg"),
    password: $("#password"),
    passwordMsg: $("#password-msg"),
    confirm: $("#confirm"),
    confirmMsg: $("#confirm-msg"),
    fname: $("#fname"),
    fnameMsg: $("#fname-msg"),
    lname: $("#lname"),
    lnameMsg: $("#lname-msg"),
    email: $("#email"),
    emailMsg: $("#email-msg"),
  };
  /**
 * Reset Form
 */
function resetForm() {
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
    document.getElementById("confirm").value = "";
    document.getElementById("lname").value = "";
    document.getElementById("fname").value = "";
    document.getElementById("email").value = "";
    document.getElementById("username-msg").style.display = "none";
    document.getElementById("password-msg").style.display = "none";
    document.getElementById("confirm-msg").style.display = "none";
    document.getElementById("lname-msg").style.display = "none";
    document.getElementById("fname-msg").style.display = "none";
    document.getElementById("email-msg").style.display = "none";
    document.getElementById("submit").style.display = "block";
  }
  

/**
 * Registeration validation functions and conditional statements
 * using ternary operator 
 */
function validate ( )
{
    let valid = true;
    reset_form ( );
// checking register details and assessung the requirements
    valid = !USERNAME.value? (USERNAME_MSG.innerHTML = "Enter a Username!", USERNAME_MSG.style.display = "block", false): true;
    valid = USERNAME.value.length < 5? (USERNAME_MSG.innerHTML = "Username must be 5 characters or more", USERNAME_MSG.style.display = "block", false): true;
    valid = USERNAME.val() !== USERNAME.val().toLowerCase() ? (USERNAME_MSG.html("Username must be all lowercase").show(), false) : true;
    valid = !PASSWORD.val() ? (PASSWORD_MSG.html("Password needs to be at least 8 characters long") && PASSWORD_MSG.show(), false) : PASSWORD.val().length < 8 ? (PASSWORD_MSG.html("Password needs to be at least 8 characters long") && PASSWORD_MSG.show(), false) : true;
    valid = (!CONFIRM.val() || PASSWORD.val() !== CONFIRM.val()) ? (CONFIRM_MSG.html("Passwords don't match"), CONFIRM_MSG.show(), false) : valid;
    valid = !FNAME.val() ? (FNAME_MSG.html("First name must not be empty"), FNAME_MSG.show(), false) : valid;
    valid = !(!LNAME.val()) ? (LNAME_MSG.html("Last name must not be empty"), LNAME_MSG.show(), false) : valid;
//email parameters using regular expression
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const email = EMAIL.val().trim();
    if (!emailPattern.test(email)) {
      EMAIL_MSG.html("Enter a valid email address");
      EMAIL_MSG.show();
      valid = false;
    }
    
    if (valid) reset_form();

}
// validate bind function
$(document).ready ( validate );
$(document).on("change", "#USERNAME, #PASSWORD, #CONFIRM, #LNAME, #FNAME, #EMAIL", validate);


